create function ip2int(ipaddr text) returns bigint
    language sql
as
$$
select split_part($1,'.',1)::bigint*16777216 + split_part($1,'.',2)::bigint*65536 + split_part($1,'.',3)::bigint*256 + split_part($1,'.',4)::bigint;
$$;

alter function ip2int(text) owner to irds_irdsdb_user;

